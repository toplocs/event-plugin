import{_ as t,__tla as a}from"./EventCreateView.vue_vue_type_script_setup_true_lang-CKvZ8aR5.js";let _=Promise.all([(()=>{try{return a}catch{}})()]).then(async()=>{});export{_ as __tla,t as default};
