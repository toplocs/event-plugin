import{_ as t,__tla as a}from"./EventListView.vue_vue_type_script_setup_true_lang-yhHOn6kI.js";let _=Promise.all([(()=>{try{return a}catch{}})()]).then(async()=>{});export{_ as __tla,t as default};
