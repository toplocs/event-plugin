-- AlterTable
ALTER TABLE "Event" ALTER COLUMN "recurring" SET DEFAULT 'Once';
